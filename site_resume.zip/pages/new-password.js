import { NewPasswordPage as ContainerPageNewPassword } from "../src/containers/new-password"

const NewPasswordPage = () => {
    return (
        <ContainerPageNewPassword />
    )
}

export default NewPasswordPage;
