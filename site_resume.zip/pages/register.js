import { RegisterPage as ContainerPageRegisterPage } from "../src/containers/registerPage"

const RegisterPage = () => {
    return (
        <ContainerPageRegisterPage />
    )
}

export default RegisterPage;
