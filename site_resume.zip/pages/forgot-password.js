import { ForgotPasswordPage as ContainerPageForgotPasswordPage } from "../src/containers/forgot-password-page"

const ForgotPasswordPage = () => {
    return (
        <ContainerPageForgotPasswordPage />
    )
}

export default ForgotPasswordPage;
