import Head from "next/head"
import { withRouter } from "next/router"
import { Provider } from "react-redux"

import App from "../src/App";

import { store } from '../src/store'

import '../public/styles/style.scss'

const MyApp = ({ Component, pageProps }) => {
  return (
    <Provider store={store}>
      <Head>
        <meta httpEquiv="Content-type" content="text/html;charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" type="image/x-icon" href="/static/favicon.ico" />
      </Head>
      <App
      >
        <Component
          {...pageProps}
        />
      </App>
    </Provider>
  )
}

export default MyApp;