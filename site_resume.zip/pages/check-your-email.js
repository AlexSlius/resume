import { CheckYourEmailPage as ContainerCheckYourEmailPage } from "../src/containers/check-your-email"

const CheckYourEmailPage = () => {
    return (
        <ContainerCheckYourEmailPage />
    )
}

export default CheckYourEmailPage;
