import WrapepeAdminpage from "../../src/wrappers/adminPage/AdminPage"
import ContainerPageEmploment from "../../src/containers/resume-builder/employment/Employment"

const ResumeEmplomentPage = () => {
    return (
        <WrapepeAdminpage>
            <ContainerPageEmploment />
        </WrapepeAdminpage>
    )
}

export default ResumeEmplomentPage;
