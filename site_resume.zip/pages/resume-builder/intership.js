import WrapepeAdminpage from "../../src/wrappers/adminPage/AdminPage"
import ContainerPageInterShip from "../../src/containers/resume-builder/intership/InterShip"

const ResumeInterShipPage = () => {
    return (
        <WrapepeAdminpage>
            <ContainerPageInterShip />
        </WrapepeAdminpage>
    )
}

export default ResumeInterShipPage;
