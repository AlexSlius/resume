import WrapepeAdminpage from "../../src/wrappers/adminPage/AdminPage"
import ContainerPageHobies from "../../src/containers/resume-builder/hobbies/Hobies"

const ResumeHobiesPage = () => {
    return (
        <WrapepeAdminpage>
            <ContainerPageHobies />
        </WrapepeAdminpage>
    )
}

export default ResumeHobiesPage;
