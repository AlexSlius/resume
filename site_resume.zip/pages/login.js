import { LoginPage as ContainerPageLoginPage } from "../src/containers/loginPage"

const LoginPage = () => {
    return (
        <ContainerPageLoginPage />
    )
}

export default LoginPage;
