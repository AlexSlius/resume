
import { configureStore } from '@reduxjs/toolkit';
import { createWrapper } from "next-redux-wrapper"

import { rootReducer } from './root-reducer';

export const store = configureStore({
  reducer: rootReducer
});

