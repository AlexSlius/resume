import { CFormInput } from "@coreui/react"

import style from "./Style.module.scss"

export const InputCode = () => {
    return (
        <div className={`${style.rows}`}>
            <div className={`${style.item_filed}`}>
                <CFormInput
                    // onChange={(e) =>setEmail(e.target.value)}
                    // value={props.value}
                    type="text"
                    placeholder='_'
                    className={`${style.in_code}`}
                />
            </div>
            <div className={`${style.item_filed}`}>
                <CFormInput
                    // onChange={(e) =>setEmail(e.target.value)}
                    // value={props.value}
                    type="text"
                    placeholder='_'
                    className={`${style.in_code}`}
                />
            </div>
            <div className={`${style.item_filed}`}>
                <CFormInput
                    // onChange={(e) =>setEmail(e.target.value)}
                    // value={props.value}
                    type="text"
                    placeholder='_'
                    className={`${style.in_code}`}
                />
            </div>
            <div className={`${style.item_filed}`}>
                <CFormInput
                    // onChange={(e) =>setEmail(e.target.value)}
                    // value={props.value}
                    type="text"
                    placeholder='_'
                    className={`${style.in_code}`}
                />
            </div>
            <div className={`${style.item_filed}`}>
                <CFormInput
                    // onChange={(e) =>setEmail(e.target.value)}
                    // value={props.value}
                    type="text"
                    placeholder='_'
                    className={`${style.in_code}`}
                />
            </div>
            <div className={`${style.item_filed}`}>
                <CFormInput
                    // onChange={(e) =>setEmail(e.target.value)}
                    // value={props.value}
                    type="text"
                    placeholder='_'
                    className={`${style.in_code}`}
                />
            </div>
        </div>
    )
}