import {
    CFormCheck
} from "@coreui/react"

import style from "./Style.module.scss"

export const Checked = (props) => {
    return (
        <div className={`${style.main}`}>
            <CFormCheck label={props.label} />
        </div>
    )
}