import DP from "react-datepicker"

// import "./DatePicker.module.scss"

export const DatePicker = (props) => {
    return (
        <DP
            {...props}
        />
    )
}