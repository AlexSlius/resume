import {
   CSidebar,
   CSidebarNav,
   CNavItem,
} from "@coreui/react"

// import Link from "next/link"
import Link from "next/link"
import Icon from "../Icon"
import ActiveLink from "../Active-link"

import vars from "./varsStyle"
import style from './SideBar.module.scss'

import contactIcon from "/public/images/icons/contact.svg?sprite"
import employmentIcon from '/public/images/icons/employment.svg?sprite'
import educationIcon from '/public/images/icons/education.svg?sprite'
import skillsIcon from '/public/images/icons/skills.svg?sprite'
import socialIcon from '/public/images/icons/social.svg?sprite'
import hobbiesIcon from '/public/images/icons/hobies.svg?sprite'
import activityIcon from '/public/images/icons/activities.svg?sprite'
import coursesIcon from '/public/images/icons/courses.svg?sprite'
import internshipIcon from '/public/images/icons/intership.svg?sprite'
import languagesIcon from '/public/images/icons/languages.svg?sprite'
import referencesIcon from '/public/images/icons/references.svg?sprite'
import certificationsIcon from '/public/images/icons/certifications.svg?sprite'
import helpIcon from '/public/images/icons/chat.svg?sprite'

const routerLinks = [
   {
      name: 'Contact',
      link: '/resume-builder',
      icon: contactIcon
   },
   {
      name: 'Employment',
      link: '/resume-builder/employment',
      icon: employmentIcon
   },
   {
      name: 'Education',
      link: '/resume-builder/education',
      icon: educationIcon
   },
   {
      name: 'Skills',
      link: '/resume-builder/skills',
      icon: skillsIcon
   },
   {
      name: 'Social Links',
      link: '/resume-builder/socials',
      icon: socialIcon
   },
   {
      name: 'Hobbies',
      link: '/resume-builder/hobies',
      icon: hobbiesIcon
   },
   {
      name: 'Extra-curricular activities',
      link: '/resume-builder/activity',
      icon: activityIcon
   },
   {
      name: 'Courses',
      link: '/resume-builder/course',
      icon: coursesIcon
   },
   {
      name: 'Internship',
      link: '/resume-builder/intership',
      icon: internshipIcon
   },
   {
      name: 'Languages',
      link: '/resume-builder/languages',
      icon: languagesIcon
   },
   {
      name: 'References',
      link: '/resume-builder/reference',
      icon: referencesIcon
   },
   {
      name: 'Certifications',
      link: '/resume-builder/certificaties',
      icon: certificationsIcon
   }
];

const SideBar = () => {
   return (
      <CSidebar style={vars}>
         <Link href="/" className={`${style.nav_logo}`}>
            Res<span>Tamplate</span>
         </Link>
         <CSidebarNav>
            {
               routerLinks.map((obj, index) => (
                  <CNavItem key={index}>
                     <ActiveLink href={`${obj.link}`} activeClassName="active">
                        <a className={`${style.nav_link} nav-link`}>
                           <Icon svg={obj.icon} classNames={[style.nav_icon, 'nav-icon']} />
                           {obj.name || ""}
                        </a>
                     </ActiveLink>
                  </CNavItem>
               ))
            }
         </CSidebarNav>
         <div className={`${style.nav_help}`}>
            <Link href="/certificaties" className={`${style.nav_help_link}`}>
               <Icon svg={helpIcon} classNames={[style.nav_icon, 'nav-icon']} />
               Need help?
            </Link>
         </div>
      </CSidebar>
   )
}

export default SideBar;