// import { useSelector } from 'react-redux';

import style from './ResumeHead.module.scss'

import savedIcon from '/public/images/icons/saved.svg?sprite'
import arrowLeftIcon from '/public/images/icons/arrow-left.svg?sprite'
import arrowRightIcon from '/public/images/icons/arrow-right.svg?sprite'
import arrowProfileIcon from '/public/images/icons/arrow-profile.svg?sprite'

import Icon from '../../Icon'

const ResumeHead = () => {
   // const contact = useSelector((state) => state.contact.contact);

   return (
      <div className={`${style.resume_head}`}>
         <div className={`${style.resume_head__status}`}>
            <Icon svg={savedIcon} classNames={[style.icon]}/>
            Saved
         </div>
         <div className={`${style.resume_head__pagination}`}>
            <button className={`${style.resume_head__pagination_button}`}>
               <Icon svg={arrowLeftIcon} classNames={[style.icon]}/>
            </button>
            <p>1/2</p>
            <button className={`${style.resume_head__pagination_button}`}>
               <Icon svg={arrowRightIcon} classNames={[style.icon]}/>
            </button>
         </div>
         <div className={`${style.resume_head__profile}`}>
            <div className={`${style.resume_head__avatar_img}`}>
               <img src={`/images/other/avatar-small.png`} alt="" />
               {/* <img src={contact?.picture || avatar} alt="" /> */}
            </div>
            <button className={`${style.resume_head__profile_arrow}`}>
               <Icon svg={arrowProfileIcon} classNames={[style.icon]}/>
            </button>
         </div>
      </div>

   )
}
export default ResumeHead;