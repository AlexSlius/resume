export const ROUTES = {
    '': 'contact',
    'employment': 'employment',
    'education': 'education',
    'skills': 'skills',
    'socials': 'socials',
    'hobies': 'hobies',
    'activity': 'activity',
    'course': 'course',
    'intership': 'intership',
    'languages': 'languages',
    'reference': 'reference',
    'certificaties': 'certificaties'
}