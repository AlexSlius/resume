import {
    CForm,
    CFormInput,
    CCol,
    CRow,
    CButton
} from "@coreui/react"

import { FormHead } from "../../components/formhead"
import { AutorizationWrapper } from "../../wrappers/autorization"
import { InputCode } from "../../components/uis/inputCode"

export const CheckYourEmailPage = () => {
    return (
        <AutorizationWrapper>
            <>
                <FormHead title="Check your email 📬" subTitle="We sent the code to reset the password" />
                <div className={`form_wrap form_wrap_mt`}>
                    <CForm className="row r-gap-30">
                        <CRow className="g-30 r-gap-30">
                            <CCol>
                                <InputCode />
                            </CCol>
                        </CRow >
                        <CRow>
                            <CCol>
                                <CButton className={`btn_form`} type="submit" color="blue">Restore password</CButton>
                            </CCol>
                        </CRow >
                    </CForm>
                </div>
            </>
        </AutorizationWrapper>
    )
}