
import { useState } from "react"
import { CForm, CCol, CRow, CButton } from "@coreui/react"
import axios from 'axios'
import FormData from "form-data"

import { DatePicker } from "../../../components/uis/datePicker"
import Input from "../../../components/uis/input"
import Icon from "../../../components/Icon";
import { PhotoAdd } from "../../../components/uis/photoAdd"

import style from './Contact.module.scss'
import reactComponent from '/public/images/icons/down.svg?sprite'


const FormContact = () => {
   const [visibleAllInputs, setVisibleAllInputs] = useState(false);
   const [firstName, setFirstName] = useState('');
   const [lastName, setLastName] = useState('');
   const [email, setEmail] = useState('');
   const [phone, setPhone] = useState('');
   const [country, setCountry] = useState('');
   const [nationality, setNationality] = useState('');
   const [city, setCity] = useState('');
   const [adress, setAdress] = useState('');
   const [zipCode, setZioCode] = useState('');
   const [driverLicense, setDriverLicense] = useState('');
   const [place, setPlace] = useState('');
   const [date, setDate] = useState(null);
   const [selectedFile, setSelectedFile] = useState(null);

   const handleChangeVisibility = (e) => {
      e.preventDefault();
      setVisibleAllInputs(prev => !prev);
   }

   // const handleFileSelect = (event) => {
   //    setSelectedFile(event.target.files[0])
   // }

   const formSubmit = (e) => {
      e.preventDefault();
      const formData = new FormData();

      formData.append('date_of_birth', date);
      formData.append('driver_license', driverLicense);
      formData.append('zip_code', city);
      formData.append('city', date);
      formData.append('phone', phone);
      formData.append('place_of_birth', place);
      formData.append('last_name', lastName);
      formData.append('address', adress);
      formData.append('country', country);
      formData.append('first_name', firstName);
      formData.append('nationality', nationality);
      formData.append('email', email);
      formData.append('picture', selectedFile);

      axios.post('http://resume.waytrel.pro/profile/basic/',
         formData,
         { headers: { 'Content-Type': 'multipart/form-data' }, })
         .then(res => {
            if (res.data.status === 'session_data_saved') {
               navigate('/login', {
                  state: {
                     sessionId: res.data.session_id
                  }
               });
            }
         }
         )
         .catch((error) => console.log(error))
   }

   const classButton = visibleAllInputs ? `${style.show_hidden} ${style.active}` : `${style.show_hidden}`;
   const textInButton = visibleAllInputs ? 'Hide additional details' : 'Edit additional details';

   return (
      <CForm onSubmit={formSubmit} className="row r-gap-30">
         <CRow>
            <CCol xs={6} className="gap-3">
               <div className="mb-3">
                  <Input
                     label="First Name"
                     placeholder="First Name"
                  />
               </div>
               <div className="mb-3">
                  <Input
                     label="Last Name"
                     placeholder="Last Name"
                  />
               </div>
            </CCol>
            <CCol xs={6}>
               {/* handleFileSelect={handleFileSelect} */}
               <PhotoAdd />
            </CCol>
         </CRow>
         <CRow className="g-30 r-gap-30">
            <CCol xs={6}>
               <Input
                  label="E-mail*"
                  placeholder="E-mail*"
               />
            </CCol>
            <CCol xs={6}>
               <Input
                  label="Phone"
                  placeholder="Phone"
               />
            </CCol>
            <CCol xs={6}>
               <Input
                  label="Country"
                  placeholder="Country"
               />
            </CCol>
            <CCol xs={6}>
               <Input
                  label="City"
                  placeholder="City"
               />
            </CCol>
         </CRow>
         {visibleAllInputs && <CRow className="g-30 r-gap-30">
            <CCol xs={6}>
               <Input
                  label="Adress"
                  placeholder="Adress"
               />
            </CCol>
            <CCol xs={6}>
               <Input
                  label="Zip Code"
                  placeholder="Zip Code"
               />
            </CCol>
            <CCol xs={6}>
               <Input
                  label="Driver license"
                  placeholder="Driver license"
               />
            </CCol>
            <CCol xs={6}>
               <Input
                  label="Nationality"
                  placeholder="Nationality"
               />
            </CCol>
            <CCol xs={6}>
               <Input
                  label="Place of birth"
                  placeholder="Place of birth"
               />
            </CCol>
            <CCol xs={6}>
               <DatePicker
                  selected={date ? new Date(date) : date}
                  onChange={(date) => setDate(date.toString())}
                  placeholderText="Date of birth"
                  name="date_of_birth"
                  calendarClassName="custom-datepicker"
                  wrapperClassName="custom-datepicker-wrapper-2"
                  dateFormat="MMM, yyyy"
                  showMonthYearPicker
                  showPopperArrow={false}
                  useShortMonthInDropdown={true}
               />
            </CCol>
         </CRow>}
         <CCol xs={12}>
            <button onClick={(e) => handleChangeVisibility(e)} className={`${classButton}`}>
               {textInButton}
               <Icon svg={reactComponent} classNames={[style.icon_bnt]} />
            </button>
         </CCol>
         <CCol>
            <CButton type="submit" color="blue">Continue</CButton>
         </CCol>
      </CForm>
   )
}

export default FormContact;