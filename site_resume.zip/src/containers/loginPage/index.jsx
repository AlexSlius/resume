import {
    CForm,
    CFormInput,
    CCol,
    CRow,
    CButton
} from "@coreui/react"
import Link from "next/link"

import { FormHead } from "../../components/formhead"
import { AutorizationWrapper } from "../../wrappers/autorization"
import { Checked } from "../../components/uis/checked"
import { InputPassword } from "../../components/uis/inputPassword"

export const LoginPage = () => {
    return (
        // isHidenBtnBack={true}
        <AutorizationWrapper >
            <>
                <FormHead title="Welcome back! ✌️" subTitle="Please enter your details." />
                <div className={`form_wrap form_wrap_mt`}>
                    <CForm className="row r-gap-30">
                        <CRow className="g-30 r-gap-30">
                            <CCol>
                                <CFormInput
                                    // onChange={(e) =>setEmail(e.target.value)}
                                    // value={email}
                                    type="text"
                                    floatingLabel="E-mail"
                                    placeholder="E-mail"
                                />
                            </CCol>
                        </CRow >
                        <CRow className="g-30 r-gap-30">
                            <CCol>
                                <InputPassword label="password" placeholder="password" />
                            </CCol>
                        </CRow>
                        <CRow className="r-gap-24">
                            <CCol>
                                <div className="row-remove-aut">
                                    <div className="row-remove-aut__left">
                                        <Checked label="Remember me" />
                                    </div>
                                    <div className="row-remove-aut__link">
                                        <Link href="/forgot-password" className="link-form-auth">Forgot password?</Link>
                                    </div>
                                </div>
                            </CCol>
                        </CRow>
                        <CRow>
                            <CCol>
                                <CButton className={`btn_form`} type="submit" color="blue">Sign in</CButton>
                            </CCol>
                        </CRow>
                        <CRow className="r-gap-24">
                            <CCol>
                                <div className="auth-bot-text">
                                    Don’t have an account?{' '}
                                    <Link href="#" className="link-form-auth">Request a free trial</Link>
                                </div>
                            </CCol>
                        </CRow>
                    </CForm>
                </div>
            </>
        </AutorizationWrapper>
    )
}