import {
    CForm,
    CFormInput,
    CCol,
    CRow,
    CButton
} from "@coreui/react"

import { FormHead } from "../../components/formhead"
import { AutorizationWrapper } from "../../wrappers/autorization"

export const ForgotPasswordPage = () => {
    return (
        <AutorizationWrapper>
            <>
                <FormHead title="Forgot password? 🔒" subTitle="Receive a password reset code by email" />
                <div className={`form_wrap form_wrap_mt`}>
                    <CForm className="row r-gap-30">
                        <CRow className="g-30 r-gap-30">
                            <CCol>
                                <CFormInput
                                    // onChange={(e) =>setEmail(e.target.value)}
                                    // value={email}
                                    type="text"
                                    floatingLabel="E-mail"
                                    placeholder="E-mail"
                                />
                            </CCol>
                        </CRow >
                        <CRow>
                            <CCol>
                                <CButton className={`btn_form`} type="submit" color="blue">Submit Code</CButton>
                            </CCol>
                        </CRow >
                    </CForm>
                </div>
            </>
        </AutorizationWrapper>
    )
}