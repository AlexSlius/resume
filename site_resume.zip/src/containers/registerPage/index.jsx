import {
    CForm,
    CFormInput,
    CCol,
    CRow,
    CButton
} from "@coreui/react"

import { FormHead } from "../../components/formhead"
import { AutorizationWrapper } from "../../wrappers/autorization"
import { InputPassword } from "../../components/uis/inputPassword"

export const RegisterPage = () => {
    return (
        <AutorizationWrapper>
            <>
                <FormHead title="Register ✍️" subTitle="Please enter your details." />
                <div className={`form_wrap form_wrap_mt`}>
                    <CForm className="row r-gap-30">
                        <CRow className="g-30 r-gap-30">
                            <CCol>
                                <CFormInput
                                    // onChange={(e) =>setEmail(e.target.value)}
                                    // value={email}
                                    type="text"
                                    floatingLabel="E-mail"
                                    placeholder="E-mail"
                                />
                            </CCol>
                        </CRow >
                        <CRow className="g-30 r-gap-30">
                            <CCol>
                                <InputPassword label="password" placeholder="password" />
                            </CCol>
                        </CRow >
                        <CRow className="g-30 r-gap-30">
                            <CCol>
                                <InputPassword label="Repeat password" placeholder="Repeat password" />
                            </CCol>
                        </CRow >
                        <CRow>
                            <CCol>
                                <CButton className={`btn_form`} type="submit" color="blue">Register</CButton>
                            </CCol>
                        </CRow >
                    </CForm>
                </div>
            </>
        </AutorizationWrapper>
    )
}